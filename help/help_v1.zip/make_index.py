#! /usr/bin/env python
# -*- coding: utf-8 -*-

import codecs
import sys

INPUT_INDEX = 'default.hhk'
OUTPUT_INDEX = 'default1.hhk'
INPUT_PROJECT = 'default.hhp'
OUTPUT_PROJECT = 'default1.hhp'
NAME_START = '<param name="Name" value="'
LOCAL_START = '<param name="Local" value="'
ENCODING_RU = 'windows-1251'
ENCODING_EN = 'utf-8'
ENCODING = ''

class IndexTerm:
	pass
	
def read_file(file_name):
	with codecs.open(file_name, encoding=ENCODING) as f:
		return f.readlines()
		
def read_hhk(file_name):	
	index = None
	indexes = list()
	lines = read_file(file_name)
	for line in [l.strip() for l in lines]:
		if not line: continue
		if line.startswith(NAME_START):
			if not index:
				name = line[len(NAME_START):].strip('">')
				index = IndexTerm()
				index.name = name
			continue
		if line.startswith(LOCAL_START):
			local = line[len(LOCAL_START):].strip('">')
			index.local = local
			indexes.append(index)
			index = None
	return indexes
	
def save_hhk(indexes, file_name):
	prefix = '''<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1"/>
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<OBJECT type="text/site properties">
</OBJECT>
<UL>
'''
	suffix = '</UL></BODY></HTML>'
	element = '''<LI><OBJECT type="text/sitemap">
	<param name="Name" value="%s">
	<param name="Local" value="%s">
</OBJECT></LI>	
'''
	with codecs.open(file_name, 'w', ENCODING) as f:
		f.write(prefix)
		for ind in indexes:
			f.write(element % (ind.name, ind.local))
		f.write(suffix)
	
def sort_indexes(indexes):
	return sorted(indexes, key = lambda ind: ind.name)

def save_indexes(indexes, file_name):
	with codecs.open(file_name, 'w', ENCODING) as f:
		for ind in indexes:
			f.write('%s; %s\n' % (ind.name, ind.local))

def update_project_file():
	new_project = list()
	for line in read_file(INPUT_PROJECT):
		new_project.append(line.replace(INPUT_INDEX, OUTPUT_INDEX))
	with codecs.open(OUTPUT_PROJECT, 'w', ENCODING) as f:
		f.writelines(new_project)
		
if __name__ == '__main__':
	lang = sys.argv[1] if len(sys.argv) > 1 else ''
	if lang == 'en':
		ENCODING = ENCODING_EN
	elif lang == 'ru':
		ENCODING = ENCODING_RU
	else:
		print('Language is not set')
		sys.exit()
	print('Sorting CHM index...')
	indexes = read_hhk(INPUT_INDEX)
	print('Index count: %d' % len(indexes))
	indexes = sort_indexes(indexes)
	#save_indexes(indexes, '1.txt')
	save_hhk(indexes, OUTPUT_INDEX)
	update_project_file()
	print('OK')
