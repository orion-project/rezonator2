#! /usr/bin/env python
# -*- coding: utf-8 -*-

ENCODING = 'utf-8'
START_MARKER = '{'
STOP_MARKER = '}'
COMMAND_MARKER = ':'

import codecs
import sys

class Cmd_InterfaceMenu:
	def format(self, code):
		title, link, icon = get_3_params(code, ',')
		docbook = ['<listitem>']
		if title == '-':
			docbook.append('<graphic fileref="img/separator.png"/>')
		else:
			docbook.append('<inlinegraphic fileref="toolbar/%s"/>&nbsp;' %\
				(icon if icon else 'dummy_16.png'))
			if link:
				docbook.append('<link linkend="%s">%s</link>' % (link, title))
			else:
				docbook.append(title)
		docbook.append('</listitem>')
		return docbook

		
class Cmd_GuiMenu:		
	def format(self, code):
		menu_path, shortcut = get_2_params(code, ',')
		menu_name, menu_item = get_2_params(menu_path, '->')
		docbook = ['<menuchoice>', \
			'<guimenu>%s</guimenu>' % menu_name]
		if menu_item:
			docbook.append('<guimenuitem>%s</guimenuitem>' % menu_item)
		if shortcut:
			docbook.append('<shortcut>')
			keys = shortcut.split('+')
			if len(keys) > 1:
				docbook.append('<keycombo>')
			for key in keys:
				docbook.append('<keycap>%s</keycap>' % key)
			if len(keys) > 1:
				docbook.append('</keycombo>')
			docbook.append('</shortcut>')
		docbook.append('</menuchoice>')
		return docbook
		
		
class Cmd_GuiMenuPara(Cmd_GuiMenu):		
	def format(self, code):
		docbook = super(Cmd_GuiMenuPara, self).format(code)
		docbook.insert(0, '<para>')
		docbook.append('</para>')
		return docbook

		
class Cmd_IndexTerm:
	def format(self, code):
		return ['<indexterm><primary>%s</primary></indexterm>' % code]
		
		
class Cmd_TitleIndexed:
	def format(self, code):
		title, index_aux = get_2_params(code, '|')
		docbook = ['<title>', title]
		index = title.lower()
		if index_aux:
			index += (' (%s)' % index_aux)
		docbook.append('<indexterm><primary>%s</primary></indexterm>' % index)
		docbook.append('</title>')
		return docbook
		
		
class Cmd_TitleXrefed:
	def format(self, code):
		title, id = get_2_params(code)
		xreflabel = title[:1].upper() + title[1:].lower()
		return ['<title id="%s" xreflabel="%s">%s</title>' % (id, xreflabel, title)]
	
		
class Cmd_Screenshot:
	def format(self, code):
		return ['<screenshot><graphic fileref="%s"/></screenshot>' % code]
		
		
class Cmd_ElemMatrixTocItem:
	def format(self, code):
		elem_type, elem_icon = get_2_params(code)
		if not elem_icon: elem_icon = elem_type + '24.png'
		return ['<listitem>', \
			'&nbsp;<inlinegraphic fileref="elems/%s"/>' % elem_icon, \
			'&nbsp;<xref linkend="%s"/>' % elem_type, \
			'</listitem>']
		
		
class Cmd_SectionSee:
	def format(self, code):
		docbook = ['<section><title>&See;</title><para>']
		links = code.split(',')
		for link in links:
			docbook.append('<xref linkend="%s"/>, ' % link.strip())
		docbook[-1] = docbook[-1].strip(', ') + '.'
		docbook.append('</para></section>')
		return docbook
	
	
class Cmd_TermDefinition:
	def format(self, code):
		docbook = ['<term>']
		parts = code.split('|')
		docbook.append(parts[0].strip())
		for index in parts[1:]:
			docbook.append('<indexterm><primary>%s</primary></indexterm>' % index.strip())
		docbook.append('</term>')
		return docbook
			
		
commands = {\
	'iface_menu': Cmd_InterfaceMenu(),
	'gui_menu': Cmd_GuiMenu(),
	'gui_menu_para': Cmd_GuiMenuPara(),
	'index_term': Cmd_IndexTerm(),
	'title_indexed': Cmd_TitleIndexed(),
	'title_xrefed': Cmd_TitleXrefed(),
	'screenshot': Cmd_Screenshot(),
	'elem_matrix_toc_item': Cmd_ElemMatrixTocItem(),
	'section_see': Cmd_SectionSee(),
	'term_def': Cmd_TermDefinition(),
}


def get_param(params, index):
	return params[index].strip() if len(params) > index else ''
	
def get_2_params(code, splitter = ','):
	params = code.split(splitter)
	return get_param(params, 0), get_param(params, 1)

def get_3_params(code, splitter = ','):
	params = code.split(splitter)
	return get_param(params, 0), get_param(params, 1), get_param(params, 2)

def process_line(code):
	cmd_marker = code.find(COMMAND_MARKER)
	if cmd_marker < 0: return ''
	cmd = code[:cmd_marker]
	if not cmd in commands: 
		print('Unknown command: %s' % cmd)
		return ''
	docbook = commands[cmd].format(code[cmd_marker+1:].strip())
	return '\n'.join(docbook)
	
def process_lines(input_lines):
	output_lines = list()
	for input_line in input_lines:
		start_marker = input_line.find(START_MARKER)
		stop_marker = input_line.find(STOP_MARKER)
		if start_marker < 0 or stop_marker < 0:
			output_lines.append(input_line)
			continue
		code = input_line[start_marker+len(START_MARKER):stop_marker].strip()
		docbook = process_line(code)
		if docbook:
			output_line = input_line[:start_marker] + \
				docbook + input_line[stop_marker+len(STOP_MARKER):]
			output_lines.append(output_line)
		else:
			output_lines.append(input_line)
	return output_lines

if __name__ == '__main__':
	input_file = sys.argv[1] if len(sys.argv) > 1 else ''
	if not input_file:
		print('Input file is not set')
		sys.exit()
		
	print('Preprocessing %s...' % input_file)
		
	with codecs.open(input_file, encoding=ENCODING) as f:
		input_lines = f.readlines()

	output_lines = process_lines(input_lines)
	output_file = input_file + '1'
	
	with codecs.open(output_file, 'w', ENCODING) as f:
		f.writelines(output_lines)
		
	print('OK')